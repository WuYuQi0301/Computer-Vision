

#ifndef HISTEQ_HPP
#define HISTEQ_HPP


class Histeq
{
public:

};

#endif